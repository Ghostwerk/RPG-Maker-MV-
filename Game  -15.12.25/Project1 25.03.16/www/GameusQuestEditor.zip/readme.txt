Gameus Quest Editor v1.0.0.0

This is the initial version of the editor going along with my Quest System plugin.
This program has to be ran from your project's root directory.

The interface should be pretty self-explanatory. If you have any bugs please report them
at the thread located here.

As of right now, this is just the editor for you to play around with. Since it's pretty much
done, the plugin will soon follow.

http://forums.rpgmakerweb.com/index.php?/topic/47455-gameus-quest-system/