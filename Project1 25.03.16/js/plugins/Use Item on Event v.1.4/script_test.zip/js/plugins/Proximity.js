//==
// Proximity MV Version 1.0
//==

/*:
 * @plugindesc Provides various functions for checking if one event is within range of another
 * @author Vlue
 *
 * @param Default Proximity Range
 * @desc Sets the default range to be used for proximity calls
 * @default 4
 * 
 * @param Transparent Region
 * @desc Region to specify unpassable terrain that can be seen through/over
 * @default 20
 *
 * @help Proximity Events MV!
 *  Script Calls:
 * Proximity.inprox(id, distance, line_of_sight, second_id)
 * Proximity.inprox_d(id, distance, line_of_sight)
 *
 *  -id is the id of the event (001 = 1)
 *  -distance is the distance in tiles to check (optional)
 *  -line_of_sight is whether to use line of sight or not (optional)
 *  -second_id checks between event1 and a second event instead of player (optional)
 *
 */

function Proximity() {}
 
(function() {

	var parameters = PluginManager.parameters('Proximity');
	var proxyRange = (parameters['Default Proximity Range'] || 4);
	var proxyRegion = (parameters['Transparent Region'] || 20);

	Proximity.inprox = function(id, distance, los, secondId) {
		distance = typeof distance != 'undefined' ? distance : proxyRange;
		los = typeof los != 'undefined' ? los : true;
		secondId = typeof secondId != 'undefined' ? secondId : false;
		var x = $gameMap._events[id].x;
		var y = $gameMap._events[id].y;
		var x2, y2;
		if(secondId) { 
			x2 = $gameMap._events[second_id].x;
			y2 = $gameMap._events[second_id].y;
		} else {
			x2 = $gamePlayer.x;
			y2 = $gamePlayer.y;
		}
		var x_d = x - x2; var y_d = y - y2;
		if(x_d < 0) {x_d *= -1;}
		if(y_d < 0) {y_d *= -1;}
		var t_d = x_d + y_d;
		if(t_d > distance) {return false;}
		if(los && !this.line_of_sight(x2,y2,x,y)) {return false;}
		return true;
	}
	Proximity.inprox_d = function(id, distance, los) {
		distance = typeof distance !== 'undefined' ? distance : proxyRange;
		los = typeof los !== 'undefined' ? los : true;
		if(!this.inprox(id, distance, los)) {return false;}
		var x1 = $gamePlayer.x; x2 = $gameMap._events[id].x;
		var y1 = $gamePlayer.y; y2 = $gameMap._events[id].y;
		var xx, yy;
		xx = x1 > x2 ? x1 - x2 : x2 - x1;
		yy = y1 > y2 ? y1 - y2 : y2 - y1;
		var dir = $gameMap._events[id]._direction;
		if(dir == 2 && y1 > y2 && yy >= xx) {return true;}
		if(dir == 4 && x1 < x2 && xx >= yy) {return true;}
		if(dir == 6 && x1 > x2 && xx >= yy) {return true;}
		if(dir == 8 && y1 < y2 && yy >= xx) {return true;}
		return false;
	}
	Proximity.line_of_sight = function(x,y,x2,y2) {
		var tile_array = [];
		var x_d = x - x2; y_d = y - y2;
		if(x_d < 0) {x_d *= -1;}
		if(y_d < 0) {y_d *= -1;}
		var t_d = x_d + y_d;
		for(var i = 0; i < t_d; i++) {
			var x_distance = x - x2;
			var y_distance = y - y2;
			if(x_distance < 0) {x_distance *= -1;}
			if(y_distance < 0) {y_distance *= -1;}
			if(x_distance > y_distance || y_distance == 0) {
				x < x2 ? x++ : x--;
			} else {
				y < y2 ? y++ : y--;
			}
			tile_array.push([x,y])
		}
		for(var i = 0; i < tile_array.length; i++) {
			var x3 = tile_array[i][0]; var y3 = tile_array[i][1];
			if($gameMap.regionId(x3,y3) == proxyRegion) {continue;}
			if(!$gameMap.checkPassage(x3,y3,2)) {return false;}
		}
		return true;
	}
	
})();