//==
// Quest System MV Version 1.0
//==

/*:
 * @plugindesc Do you want quests? This gives you quests!!
 * @author Vlue
 *
 * @help Quest System MV!
 * 
 *  Plugin Commands:
 *   quest accept #              -Accepts quest with an ID of #
 *   quest askAccept #           -Asks the player to accept quest #
 *   quest abandon #             -Abandons quest #
 *   quest fail #                -Fails quest #
 *   quest turnin #              -Turnins quest # (without prompt)
 *   quest askTurnin #           -Asks the player to turnin quest #
 *   quest advance # # #         -Advanced quest #'s objective number # by #
 *   quest set # # #             -Sets quest #'s objective number # to #
 *   quest hide # #              -Hides quest #'s objective number #
 *   quest show # #              -Shows quest #'s objective number #
 *
 *  Script Calls:
 *   this.obj(questId, objId)    -Returns the current value of Quest questId's objective objId
 *
 *  The joys, oh the joyyysss of creating quests! It uh.. well good luck.
 *  Anyways create a text document named Quest.txt in the data folder of the 
 *  Game Project and set up your quests in there like.. this:
 *
 *  <quest#>
 *   name:Quest Name
 *   level:#
 *   difficulty:Some Words (Easy, Normal, whatever you want)
 *   autoComplete:true/false
 *   canAbandon:true/false
 *   forceAccept:true/false
 *   forceTurnin:true/false
 *   qgiverName:Random name
 *   location:Random words
 *   <description>
 *  Some words describing the quest
 *  They can be multi-lined!
 *  Careful though... no text wrap (yet)
 *   <description>
 *   <objectives>
 *    {name:"An Objective Name", max:#, hidden:true/false}
 *    {and more as you need}
 *   <objectives>
 *   gold:#
 *   exp:#
 *   expScale:#
 *   <rewards>
 *    {type:"item" (or "weapon" or "armor"), id:#, amount:#}
 *    {and more as needed}
 *   <rewards>
 *  <quest#>
 *
 *  Everything aside from Objectives can technically be left out (will be set to default/null)
 *  The ID of the quest will be equal to the number used in <quest#> (Oh but keep them in order.. 
 *   bad things will happen other wise, no 1,2,4,5 : no 10, 563, 2, 5 : yes 1,2,3,4,5,6,7,8)
 *  Actually, they don't even need to be in order, just don't skip any numbers.
 *
 */
 
 $gameQuests = null;
 
(function() {

	var questLogMaxDisplay = 5;
	
	DataManager.loadQuestFile = function() {
		var data = null;
		var fs = require('fs');
		var path = window.location.pathname.replace(/(\/www|)\/[^\/]*$/, '/data/Quests.txt');
		if (path.match(/^\/([A-Z]\:)/)) {
			path = path.slice(1);
		}
		path = decodeURIComponent(path);
		if (fs.existsSync(path)) {
			data = fs.readFileSync(path, { encoding: 'utf8' });
		}
		return data;
	};
	var quests_DataManager_creategameobjects = DataManager.createGameObjects;
	DataManager.createGameObjects = function() {
		quests_DataManager_creategameobjects.call(this);
		$gameQuests = new Game_Quests();
	};
	
	function Game_Quests() {
		this.initialize.apply(this);
	}
	Game_Quests.prototype.initialize = function() {
		this.createQuests();
		this.resetObjectives();
		console.log(this.tracking());
	}
	Game_Quests.prototype.createQuests = function() {
		this._quests = [0];
		var questData = DataManager.loadQuestFile()
		var numberOfQuests = questData.match(/<quest(\d+)>/g).length / 2
		console.log(numberOfQuests);
		for(var i = 1;i <= numberOfQuests;i++) {
			console.log(i);
			var questString = questData.match(new RegExp("<quest" + i + '>([^.]+)<quest' + i + ">"))[1];
			var questHash = {}
			questHash.name = questString.match(/name:(.+)/);
			questHash.level = questString.match(/level:(.+)/);
			questHash.difficulty = questString.match(/difficulty:(.+)/);
			questHash.autoComplete = questString.match(/autoComplete:(.+)/);
			questHash.canAbandon = questString.match(/canAbandon:(.+)/);
			questHash.forceAccept = questString.match(/forceAccept:(.+)/);
			questHash.forceTurnin = questString.match(/forceTurnin:(.+)/);
			questHash.qgiverName = questString.match(/qgiverName:(.+)/);
			questHash.location = questString.match(/location:(.+)/);
			questHash.description = questString.match(/<description>([^.]+)<description>/);
			var objData = questString.match(/<objectives>([^.]+)<objectives>/);
			objData = eval( "[" + objData[1].split("}").join("},") + "]" );
			questHash.objectives = objData;
			questHash.gold = questString.match(/gold:(.+)/);
			questHash.exp = questString.match(/exp:(.+)/);
			questHash.expScale = questString.match(/expScale:(.+)/);
			var rewardData = questString.match(/<rewards>([^.]+)<rewards>/);
			rewardData = eval( "[" + rewardData[1].split("}").join("},") + "]" );
			questHash.rewards = rewardData;
			this._quests.push(new Quest(i, questHash));
			console.log(this._quests);
		}
	}
	Game_Quests.prototype.resetObjectives = function() {
		this._resetHash = {}
		console.log(this._resetHash);
		this._resetHash[0] = 0;
		for(var i = 1;i < this._quests.length;i++) {
			var id = this._quests[i]._id;
			console.log(id);
			this._resetHash[id] = {}
			this._resetHash[id].accepted = false;
			this._resetHash[id].turnedIn = false;
			for(var j = 0;j < this._quests[i]._objectives.length;j++) {
				this._resetHash[id][j] = this._quests[i]._objectives[j];
			}
		}
		console.log(this._resetHash);
	}
	Game_Quests.prototype.getQuest = function(questId) {
		if(typeof questId == "string") {
			for(var i = 0;i < this._quests.length;i++) {
				if(this._quests[i].name == questId) { return this._quests[i]; }
			}
		} else {
			if(this._quests[questId]) {return this._quests[questId];}
		}
		return console.log("No quest with id of " + String(questId) + " found.");
	}
	Game_Quests.prototype.anyQuests = function() {
		for(var i = 1;i < this._quests.length;i++) {
			var quest = this._quests[i];
			if(quest.accepted() && !quest.turnedIn()) { return false; }
		}
		return true;
	}
	Game_Quests.prototype.tracking = function() { return $gameParty._tracking; }
	Game_Quests.prototype.trackQuest = function(questId) {
		var tracking = this.tracking();
		console.log(questId);
		if(tracking.indexOf(questId) >= 0) { return; }
		tracking.push(questId);
		if(tracking.length > questLogMaxDisplay) {
			tracking.splice(0,1);
		}
		console.log(tracking);
	}
	Game_Quests.prototype.untrackQuest = function(questId) {
		var tracking = this.tracking();
		if(tracking.indexOf(questId) >= 0) {
			tracking.splice(tracking.indexOf(questId), 1);
		}
	}
	
	function Quest() {
		this.initialize.apply(this, arguments);
	}
	Quest.prototype.initialize = function(id, questHash) {
		this._id = id;
		this._level = questHash.level ? Number(questHash.level[1]) : 1;
		this._difficulty = questHash.difficulty ? questHash.difficulty[1] : "";
		this._name = questHash.name ? questHash.name[1] : "No Quest Name Defined";
		this._description = questHash.description ? questHash.description[1] : "";
		this._qgiverName = questHash.qgiverName ? questHash.qgiverName[1] : "";
		this._location = questHash.location ? questHash.location[1] : "";
		this._autoComplete = questHash.autoComplete ? questHash.autoComplete[1] == "true" : "false";
		this._canAbandon = questHash.canAbandon ? questHash.canAbandon[1] == "true" : "false";
		this._forceTurnin = questHash.forceTurnin ? questHash.forceTurnin[1] == "true" : "false";
		this._forceAccept = questHash.forceAccept ? questHash.forceAccept[1] == "true" : "false";
		this._needPopup = false;
		this._objectives = [];
		for(var i = 0;i < questHash.objectives.length;i++) {
			this._objectives.push(new Objective(i, questHash.objectives[i]));
		}
		this._gold = questHash.gold ? Number(questHash.gold[1]) : 0;
		this._exp = questHash.exp ? Number(questHash.exp[1]) : 0;
		this._expScale = questHash.expScale ? Number(questHash.expScale[1]) : 0;
		this._rewards = questHash.rewards || [];
	}
	Quest.prototype.accept = function() {
		this.reset();
		$gameParty.quests[this._id].accepted = true;
		this.trackQuest();
		$gameMap._needsRefresh = true;
		//Some Sound Effect Please
	}
	Quest.prototype.abandon = function() {
		this.reset();
		$gameParty.quests[this._id].accepted = false;
	}
	Quest.prototype.fail = function() {
		//Some Sounf Effect Nao
		this.abandon();
	}
	Quest.prototype.accepted = function() { return $gameParty.quests[this._id].accepted; }
	Quest.prototype.completed = function() {
		for(var i = 0;i < this._objectives.length;i++) {
			if(!$gameParty.quests[this._id][i].completed()) { return false; }
		}
		return true;
	}
	Quest.prototype.forceDone = function() {
		$gameParty.quests[this._id].accepted = true;
		for(var i = 1; 1 < this._objectives.length;i++) {
			$gameParty.quests[this._id][i].current = this._objectives[i].max;
		}
		this.turnIn();
	}
	Quest.prototype.reset = function() {
		$gameParty.quests[this._id].accepted = false;
		for(var i = 0; i < this._objectives.length;i++) {
			$gameParty.quests[this._id][i].current = 0;
		}
		$gameParty.quests[this._id].turnedIn = false;
	}
	Quest.prototype.objective = function(id) {
		return $gameParty.quests[this._id][id];
	}
	Quest.prototype.setObj = function(id, value) {
		this.objective(id).current = value;
		if(!this.completed()) { this._needPopup = false; }
		if(this.completed()) {
			if(!this._needPopup) { this.popUp(); }
			if(this._autoComplete) { this.turnIn(); }
		}
		$gameMap._needsRefresh = true;
	}
	Quest.prototype.advObj = function(id, value) {
		this.setObj(id, this.objective(id).current + value);
	}
	Quest.prototype.turnIn = function() {
		$gameParty.quests[this._id].turnedIn = true;
		this.untrackQuest();
		$gameMap._needsRefresh = true;
		$gameParty.gainGold(this._gold);
		for(var i = 0;i < $gameParty.members().length;i++) {
			$gameParty.members()[i].gainExp(this.getRewardExp());
		}
		this._rewards
		for(var i = 0;i < this._rewards.length;i++) {
			var item = $gameParty.getContainer(this._rewards[i].type)[this._rewards[i].id]
			$gameParty.gainItem(item, this._rewards[i].amount);
		}
	}
	Quest.prototype.trackQuest = function() {
		$gameQuests.trackQuest(this._id);
	}
	Quest.prototype.untrackQuest = function() {
		$gameQuests.untrackQuest(this._id);
	}
	Quest.prototype.popUp = function() {
		//Not Implemented
	}
	Quest.prototype.turnedIn = function() {
		return $gameParty.quests[this._id].turnedIn;
	}
	Quest.prototype.active = function() {
		return this.accepted() && !this.completed();
	}
	Quest.prototype.getRewardExp = function() {
		var pval = this._expScale * (this._level - $gameParty.highestLevel()) / 100 + 1;
		return this._exp * pval;
	}
	
	function Objective() {
		this.initialize.apply(this, arguments);
	}
	Objective.prototype.initialize = function(id, obj) {
		this.name = obj.name;
		this.current = 0;
		this.max = obj.max;
		this.hidden = obj.hidden;
	}
	Objective.prototype.completed = function() {
		console.log(this.current >= this.max);
		return this.current >= this.max;
	}
	
	function Scene_Quests() {
		this.initialize.apply(this, arguments);
	}
	Scene_Quests.prototype = Object.create(Scene_MenuBase.prototype);
	Scene_Quests.prototype.constructor = Scene_Quests;
	Scene_Quests.prototype.initialize = function() {
		Scene_MenuBase.prototype.initialize.call(this);
	};
	Scene_Quests.prototype.create = function() {
		Scene_MenuBase.prototype.create.call(this);
		this._helpWindow = new Window_Help(1);
		this._helpWindow.setText("Quest Log");
		this._listWindow = new Window_SceneList();
		this._listWindow.setHandler("cancel",this.listCancel.bind(this));
		this._listWindow.setHandler("ok",this.listOk.bind(this));
		this._listWindow.refresh;
		this._listWindow.activate();
		this._listWindow.select(0);
		this._commandWindow = new Window_QuestTrack();
		this._commandWindow.x = (Graphics.width - this._commandWindow.width) / 2;
		this._commandWindow.y = (Graphics.height - this._commandWindow.height) / 2;
		this._detailWindow = new Window_SceneDetail();
		this._commandWindow.setHandler("track",this.track.bind(this));
		this._commandWindow.setHandler("untrack",this.untrack.bind(this));
		this._commandWindow.setHandler("abandon",this.abandon.bind(this));
		this._commandWindow.setHandler("cancel",this.commandCancel.bind(this));
		this.addWindow(this._helpWindow);
		this.addWindow(this._listWindow);
		this.addWindow(this._detailWindow);
		this.addWindow(this._commandWindow);
	}
	Scene_Quests.prototype.update = function() {
		Scene_MenuBase.prototype.update.call(this);
		this._detailWindow.quest(this._listWindow.currentItem());
	}
	Scene_Quests.prototype.listCancel = function() {
		this.popScene();
	}
	Scene_Quests.prototype.listOk = function() {
		this._commandWindow.quest(this._listWindow.currentItem());
		this._commandWindow.refresh();
		this._commandWindow.select(0);
		this._commandWindow.activate();
		this._commandWindow.open();
	}
	Scene_Quests.prototype.track = function() {
		$gameQuests.trackQuest(this._listWindow.currentItem()._id);
		this.commandCancel();
	}
	Scene_Quests.prototype.untrack = function() {
		$gameQuests.untrackQuest(this._listWindow.currentItem()._id);
		this.commandCancel();
	}
	Scene_Quests.prototype.abandon = function() {
		this._listWindow.currentItem().abandon();
		this.commandCancel();
	}
	Scene_Quests.prototype.commandCancel = function() {
		this._commandWindow.close();
		this._listWindow.refresh();
		this._listWindow.activate();
		if($gameQuests.anyQuests()) { this.listCancel(); }
	}
	
	function Window_SceneList() {
		this.initialize.apply(this, arguments);
	}
	Window_SceneList.prototype = Object.create(Window_Selectable.prototype);
	Window_SceneList.prototype.constructor = Window_SceneList;
	Window_SceneList.prototype.initialize = function(x, y, width, height) {
		Window_Selectable.prototype.initialize.call(this, 0, this.fittingHeight(1), Graphics.width/5*2,Graphics.height - this.fittingHeight(1));
		this.refresh();
	};
	Window_SceneList.prototype.makeItemList = function() {
		this._data = [];
		for(var i = 1;i < $gameQuests._quests.length;i++) {
			var quest = $gameQuests._quests[i];
			if(quest.accepted() && !quest.turnedIn()) {
				this._data.push(quest);
			}
		}
		console.log(this._data);
		if(this._data.length == 0) { this._data.push(null); }
	}
	Window_SceneList.prototype.drawItem = function(index) {
		var item = this._data[index];
		if(item) {
			var rect = this.itemRect(index);
			rect.width -= 4;
			var text = item._name;
			if($gameQuests.tracking().indexOf(item._id) >= 0) {
				text = "*" + text;
			} 
			this.drawText(text,rect.x,rect.y,rect.width);
			if(item.level > 0) { this.drawText("Lv" + String(item._level),rect.x,rect.y,rect.width,"right"); }
		}
	}
	Window_SceneList.prototype.currentItem = function() { return this._data[this.index()]; }
	Window_SceneList.prototype.isCurrentItemEnabled = function() { return true; }
	Window_SceneList.prototype.refresh = function() { 
		this.makeItemList();
		this.createContents();
		this.drawAllItems();
	}
	Window_SceneList.prototype.maxItems = function() { return this._data ? this._data.length : 0; }
	
		
	function Window_SceneDetail() {
		this.initialize.apply(this, arguments);
	}
	Window_SceneDetail.prototype = Object.create(Window_Base.prototype);
	Window_SceneDetail.prototype.constructor = Window_SceneDetail;
	Window_SceneDetail.prototype.initialize = function(x, y, width, height) {
		Window_Base.prototype.initialize.call(this, 
		  Graphics.width/5*2, this.fittingHeight(1), Graphics.width - Graphics.width/5*2,
		  Graphics.height - this.fittingHeight(1));
	}
	Window_SceneDetail.prototype.quest = function(quest) {
		if(this._quest == quest) { return; }
		this._quest = quest;
		this.refresh();
	}
	Window_SceneDetail.prototype.lineHeight = function() { return 30; }
	Window_SceneDetail.prototype.refresh = function() {
		this.contents.clear();
		this.contents.fontSize = 24;
		if(this._quest) {
			this.changeTextColor(this.systemColor());
			this.drawText(this._quest._qgiverName,0,0,this.contents.width);
			this.drawText(this._quest._location,0,0,this.contents.width,"right");
			var yy = 0;
			if(this._quest._qgiverName != "" || this._quest._location != "") { 
				yy = this.lineHeight();
			}
			this.drawText("Objectives",0,this.lineHeight() * 7,this.contents.width);
			this.changeTextColor(this.normalColor());
			this.drawTextEx(this._quest._description,0,yy);
			yy = this.lineHeight() * 8;
			for(var i = 0;i < this._quest._objectives.length;i++) {
				var obj = this._quest.objective(i);
				if(obj.hidden) { continue; }
				this.drawObjective(yy,obj);
				yy += this.lineHeight();
			}
			this.changeTextColor(this.systemColor());
			this.drawText("Rewards",0,yy,this.contents.width);
			yy += this.lineHeight();
			if(this._quest.getRewardExp() > 0) {
				this.drawText("XP: ",6,yy,this.contents.width/2);
				this.changeTextColor(this.normalColor());
				this.drawText(this._quest.getRewardExp(),48,yy,this.contents.width/2);
				yy += this.lineHeight();
			}
			if(this._quest._gold > 0) {
				this.changeTextColor(this.normalColor());
				this.drawText(this._quest._gold,6,yy,this.contents.width/2);
				var cx = this.textWidth(this._quest._gold);
				this.changeTextColor(this.systemColor());
				this.drawText(TextManager.currencyUnit,8+cx,yy,this.contents.width/2);
			}
			yy += this.lineHeight();
			this.changeTextColor(this.normalColor());
			for(var i = 0;i < this._quest._rewards.length;i++) {
				var item = $gameParty.getContainer(this._quest._rewards[i].type)[this._quest._rewards[i].id];
				this.drawItemName(item, 6, yy);
				if(this._quest._rewards[i].amount > 1) {
					this.drawText("x"+this._quest._rewards[i].amount,6+this.textWidth(item.name)+42,yy,48);
				}
				yy += this.lineHeight();
			}
			if(this._quest._difficulty != "") {
				this.drawText("Difficulty: " + this._quest._difficulty,0,this.contents.height - this.lineHeight(),this.contents.width,"right");
			}
		}
	}
	Window_SceneDetail.prototype.drawObjective = function(yy, obj) {
		this.drawText(obj.name,6,yy,this.contents.width);
		this.drawText(obj.current + "/" + obj.max,0,yy,this.contents.width,"right");
	}
	Window_SceneDetail.prototype.resetFontSettings = function() {
		this.contents.fontFace = this.standardFontFace();
		this.resetTextColor();
	};
	
	function Window_QuestTrack() {
		this.initialize.apply(this, arguments);
	}
	Window_QuestTrack.prototype = Object.create(Window_Command.prototype);
	Window_QuestTrack.prototype.constructor = Window_QuestTrack;
	Window_QuestTrack.prototype.initialize = function() {
		Window_Command.prototype.initialize.call(this, 0,0);
		this.openness = 0;
	}
	Window_QuestTrack.prototype.quest = function(quest) {
		this._quest = quest;
	}
	Window_QuestTrack.prototype.makeCommandList = function() {
		if(this._quest) {
			if($gameQuests.tracking().indexOf(this._quest._id) >= 0) {
				this.addCommand("Untrack Quest", 'untrack');
			} else {
				this.addCommand("Track Quest", 'track');
			}
			this.addCommand("Abandon Quest", 'abandon', this._quest._canAbandon);
		}
	}
	Window_QuestTrack.prototype.windowHeight = function() {
		return this.fittingHeight(2);
	}
	
	var quest_window_menucommand_addoriginalcommands = Window_MenuCommand.prototype.addOriginalCommands;
	Window_MenuCommand.prototype.addOriginalCommands = function() {
		quest_window_menucommand_addoriginalcommands.call(this);
		this.addCommand("Quest Log", 'quest', !$gameQuests.anyQuests());
	}
		
	var quest_scene_menu_createcommandwindow = Scene_Menu.prototype.createCommandWindow;
	Scene_Menu.prototype.createCommandWindow = function() {
		quest_scene_menu_createcommandwindow.call(this);
		this._commandWindow.setHandler('quest', this.sceneQuest.bind(this));
	};
	Scene_Menu.prototype.sceneQuest = function() {
		SceneManager.push(Scene_Quests);
	}
	
	var quest_scene_map_create = Scene_Map.prototype.createAllWindows;
	var quest_scene_map_update = Scene_Map.prototype.update;
	var quest_scene_map_ismenuok = Scene_Map.prototype.isMenuEnabled;
	Scene_Map.prototype.createAllWindows = function() {
		this._questLog = new Window_QuestLog();
		this._questConfirm = new Window_QuestConfirm();
		this._questConfirm.setHandler('accept', this.confirmAccept.bind(this));
		this._questConfirm.setHandler('decline', this.confirmCancel.bind(this));
		this._questConfirm.setHandler('cancel', this.confirmCancel.bind(this));
		this._questTurnin = new Window_QuestTurnin();
		this._questTurnin.setHandler('accept', this.turninAccept.bind(this));
		this._questTurnin.setHandler('decline', this.confirmCancel.bind(this));
		this._questTurnin.setHandler('cancel', this.confirmCancel.bind(this));
		this._questApply = new Window_QuestApply(this._questConfirm,this._questTurnin);
		this.addWindow(this._questLog);
		this.addWindow(this._questConfirm);
		this.addWindow(this._questTurnin);
		this.addWindow(this._questApply);
		quest_scene_map_create.call(this);
	}
	Scene_Map.prototype.showQuest = function(id, turnin) {
		this._questApply.show($gameQuests.getQuest(id),turnin || false);
	}
	Scene_Map.prototype.accepting = function() {
		return this._questConfirm.active || this._questTurnin.active;
	}
	Scene_Map.prototype.confirmAccept = function() {
		this._questApply.accept();
		this._questApply.hide();
	}
	Scene_Map.prototype.confirmCancel = function() {
		this._questApply.hide();
	}
	Scene_Map.prototype.turninAccept = function() {
		this._questApply.turnin();
		this._questApply.hide();
	}
	Scene_Map.prototype.isMenuEnabled = function() {
		return quest_scene_map_ismenuok.call(this) && !this.accepting();
	};

	Scene_Base.prototype.accepting = function() { return false; }
	
	function Window_QuestLog() {
		this.initialize.apply(this, arguments);
	}
	Window_QuestLog.prototype = Object.create(Window_Base.prototype);
	Window_QuestLog.prototype.constructor = Window_QuestLog;
	Window_QuestLog.prototype.initialize = function() {
		Window_Base.prototype.initialize.call(this, Graphics.width/5*3,0,Graphics.width/5*2,Graphics.height);
		this.opacity = 0
		this.contents.fontSize = 18;
	}
	Window_QuestLog.prototype.update = function() {
		Window_Base.prototype.update.call(this);
		if(Graphics.frameCount % 20 == 0) {
			this.visible = $gameQuests.anyQuests();
			this.visible = $gameQuests.tracking().length > 0;
			if(this.visible) {
				this.contents.clear();
				this.changeTextColor(this.crisisColor());
				this.drawText("Quest Log:",0,0,this.contents.width,'center');
				var yy = 24;
				for(var i = 0;i < $gameQuests.tracking().length;i++) {
					var quest = $gameQuests._quests[$gameQuests.tracking()[i]];
					if(quest.accepted() && !quest.turnedIn()) {
						this.changeTextColor(this.systemColor());
						this.drawText(quest._name,0,yy,this.contents.width - 6);
						this.changeTextColor(this.normalColor());
						yy += 24;
						for(var j = 0;j < quest._objectives.length;j++) {
							var objective = quest.objective(j);
							if(objective.hidden) { continue; }
							this.drawObjective(yy,$gameParty.quests[quest._id][j]);
							yy += 24;
						}
					}
				}
			}
		}
	}
	Window_QuestLog.prototype.drawObjective = function(yy, obj) {
		this.drawText(obj.name,6,yy,this.contents.width-24);
		this.drawText(String(obj.current) + "/" + String(obj.max),0,yy,this.contents.width,'right');
	}
	
	function Window_QuestApply() {
		this.initialize.apply(this, arguments);
	}
	Window_QuestApply.prototype = Object.create(Window_Base.prototype);
	Window_QuestApply.prototype.constructor = Window_QuestApply;
	Window_QuestApply.prototype.initialize = function(conwin, turnwin) {
		Window_Base.prototype.initialize.call(this, Graphics.width/8,Graphics.width/8,Graphics.width/5*3,
			Graphics.height - Graphics.width/8*2);
		this.openness = 0
		this._confirmWindow = conwin;
		this._turninWindow = turnwin;
		this.contents.fontSize = 18;
	}
	Window_QuestApply.prototype.lineHeight = function() { return 21; }
	Window_QuestApply.prototype.refresh = function() {
		if(this._quest) {
			this.contents.clear();
			this.changeTextColor(this.systemColor());
			var yy = 0;
			if(this._quest._qgiverName != "") {
				this.drawText(this._quest._qgiverName,0,0,this.contents.width/2);
				yy += this.lineHeight();
			}
			if(this._quest._location != "") {
				this.drawText(this._quest._location,this.contents.width/2,0,this.contents.width/2);
				yy += this.lineHeight();
			}
			this.changeTextColor(this.crisisColor());
			if(this._quest._level > 0) {
				this.drawText("Lvl: " + String(this._quest._level),0,yy,this.contents.width);
			}
			this.drawText(this._quest._name,0,yy,this.contents.width,'center');
			if(this._quest._difficulty != "") {
				this.drawText(this._quest._difficulty,0,yy,this.contents.width,'right');
			}
			this.changeTextColor(this.systemColor());
			this.drawText("Objectives:",0,this.lineHeight() * 10,this.contents.width);
			this.drawTextEx(this._quest._description,0,this.lineHeight() + yy);
			yy = this.lineHeight() * 11;
			for(var i = 0;i < this._quest._objectives.length;i++) {
				var objective = this._quest.objective(i);
				if(objective.hidden) { continue; }
				this.drawObjective(yy,$gameParty.quests[this._quest._id][i]);
				yy += 24;
			}
			this.changeTextColor(this.systemColor());
			this.drawText("Rewards:",0,yy,this.contents.width);
			yy += this.lineHeight();
			if(this._quest.getRewardExp() > 0) {
				this.drawText("XP: ",6,yy,this.contents.width/2);
				this.changeTextColor(this.normalColor());
				this.drawText(this._quest.getRewardExp(),48,yy,this.contents.width/2);
				yy += this.lineHeight();
			}
			if(this._quest._gold > 0) {
				this.changeTextColor(this.normalColor());
				this.drawText(this._quest._gold,6,yy,this.contents.width/2);
				var cx = this.textWidth(this._quest._gold);
				this.changeTextColor(this.systemColor());
				this.drawText(TextManager.currencyUnit,8+cx,yy,this.contents.width/2);
			}
			yy += this.lineHeight();
			this.changeTextColor(this.normalColor());
			for(var i = 0;i < this._quest._rewards.length;i++) {
				var item = $gameParty.getContainer(this._quest._rewards[i].type)[this._quest._rewards[i].id];
				this.drawItemName(item, 6, yy);
				if(this._quest._rewards[i].amount > 1) {
					this.drawText("x"+this._quest._rewards[i].amount,6+this.textWidth(item.name)+42,yy,48);
				}
				yy += this.lineHeight();
			}
		}
	}
	Window_QuestApply.prototype.resetFontSettings = function() {
		this.contents.fontFace = this.standardFontFace();
		this.resetTextColor();
	};
	Window_QuestApply.prototype.drawObjective = function(yy, obj) {
		this.drawText(obj.name,6,yy,this.contents.width-24);
		this.drawText(String(obj.current) + "/" + String(obj.max),0,yy,this.contents.width,'right');
	}
	Window_QuestApply.prototype.show = function(quest, turnin) {
		this._quest = quest;
		console.log(this._quest);
		if(this._quest.turnedIn()) { return; }
		if(turnin && !this._quest.accepted()) { return; }
		this.refresh();
		this.open();
		this._confirmWindow.quest(this._quest);
		this._turninWindow.quest(this._quest);
		if(turnin) {
			this._turninWindow.open();
		} else {
			this._confirmWindow.open();
		}
	}
	Window_QuestApply.prototype.hide = function() {
		this.close();
		this._confirmWindow.close();
		this._turninWindow.close();
	}
	Window_QuestApply.prototype.accept = function() {
		this._quest.accept();
	}
	Window_QuestApply.prototype.turnin = function() {
		this._quest.turnIn();
	}
	
	function Window_QuestConfirm() {
		this.initialize.apply(this, arguments);
	}
	Window_QuestConfirm.prototype = Object.create(Window_HorzCommand.prototype);
	Window_QuestConfirm.prototype.constructor = Window_QuestConfirm;
	Window_QuestConfirm.prototype.initialize = function() {
		Window_HorzCommand.prototype.initialize.call(this, Graphics.width/8,Graphics.width/8+Graphics.height-Graphics.width/8*2);
		this.openness = 0;
		this.active = false;
		this._enabled = true;
		this.refresh();
	}
	Window_QuestConfirm.prototype.windowWidth = function() { return Graphics.width/5*2; }
	Window_QuestConfirm.prototype.windowHeight = function() { return this.fittingHeight(1); }
	Window_QuestConfirm.prototype.makeCommandList = function() {
		this.addCommand("Accept",'accept');
		this.addCommand("Decline",'decline',this._enabled);
	}
	Window_QuestConfirm.prototype.itemWidth = function() {
		return this.width / 2 - this.padding * 2;
	}
	Window_QuestConfirm.prototype.open = function() {
		Window_HorzCommand.prototype.open.call(this);
		this.activate();
		this.select(0);
	}
	Window_QuestConfirm.prototype.quest = function(quest) {
		this._quest = quest;
		this._enabled = !this._quest._forceAccept;
		this.refresh();
	}
	Window_QuestConfirm.prototype.isCancelEnabled = function() {
		return Window_HorzCommand.prototype.isCancelEnabled.call(this) && this._enabled;
	}
	
	function Window_QuestTurnin() {
		this.initialize.apply(this, arguments);
	}
	Window_QuestTurnin.prototype = Object.create(Window_QuestConfirm.prototype);
	Window_QuestTurnin.prototype.constructor = Window_QuestTurnin;
	Window_QuestTurnin.prototype.initialize = function() {
		Window_QuestConfirm.prototype.initialize.call(this);
	}
	Window_QuestTurnin.prototype.quest = function(quest) {
		console.log(quest);
		this._quest = quest;
		this._enabled = true;
		if(this._quest._forceTurnin && this._quest.completed()) { this._enabled = false; }
		this.refresh();
	}
	Window_QuestTurnin.prototype.makeCommandList = function() {
		if(this._quest) {
			this.addCommand("Complete",'accept',this._quest.completed());
			this.addCommand("Cancel",'decline',this._enabled);
		}
	}
	
	var quest_game_party_initialize = Game_Party.prototype.initialize;
	Game_Party.prototype.initialize = function() {
		quest_game_party_initialize.call(this);
		if($gameQuests) { this.quests = $gameQuests._resetHash; }
		console.log(this.quests);
		this._tracking = [];
	}
	Game_Party.prototype.getContainer = function(item) {
		if(item == "weapon") {return $dataWeapons; }
		if(item == "armor") {return $dataArmors; }
		if(item == "item") {return $dataItems; }
		return [];
	}
	
	var quest_game_player_update = Game_Player.prototype.update;
	Game_Player.prototype.update = function(sceneUpdate) {
		if(SceneManager._scene.accepting()) { return; }
		quest_game_player_update.call(this, sceneUpdate);
	}
	
	var quest_Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
	Game_Interpreter.prototype.pluginCommand = function(command, args) {
		quest_Game_Interpreter_pluginCommand.call(this, command, args);
		if(command === 'quest' && args[0] === 'accept') {
			$gameQuests.getQuest(Number(args[1])).accept();
		}
		if(command === 'quest' && args[0] === 'askAccept') {
			SceneManager._scene.showQuest(Number(args[1]));
			this.setWaitMode('questAccept');
		}
		if(command === 'quest' && args[0] === 'abandon') {
			$gameQuests.getQuest(Number(args[1])).abandon();
		}
		if(command === 'quest' && args[0] === 'fail') {
			$gameQuests.getQuest(Number(args[1])).fail();
		}
		if(command === 'quest' && args[0] === 'turnin') {
			$gameQuests.getQuest(Number(args[1])).turnin();
		}
		if(command === 'quest' && args[0] === 'askTurnin') {
			SceneManager._scene.showQuest(Number(args[1]),true);
			this.setWaitMode('questAccept');
		}
		if(command === 'quest' && args[0] === 'advance') {
			$gameQuests.getQuest(Number(args[1])).advObj(Number(args[2]),Number(args[3]));
		}
		if(command === 'quest' && args[0] === 'set') {
			$gameQuests.getQuest(Number(args[1])).setObj(Number(args[2]),Number(args[3]));
		}
		if(command === 'quest' && args[0] === 'hide') {
			$gameQuests.getQuest(Number(args[1])).objective(Number(args[2])).hidden = true;
		}
		if(command === 'quest' && args[0] === 'show') {
			$gameQuests.getQuest(Number(args[1])).objective(Number(args[2])).hidden = false;
		}
	}
	var quest_Game_Interpreter_updateWaitMode = Game_Interpreter.prototype.updateWaitMode;
	Game_Interpreter.prototype.updateWaitMode = function() {
		var waiting = false;
		if(this._waitMode == 'questAccept') { waiting = SceneManager._scene.accepting()}
		if (!waiting) {
			waiting = quest_Game_Interpreter_updateWaitMode.call(this);
		}
		return waiting;
	};
	Game_Interpreter.prototype.obj = function(questId, objId) {
		return $gameQuests.getQuest(questId).objective(objId).current;
	}
	
})();