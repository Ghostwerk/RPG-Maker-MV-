//==
// Interesting Stats MV Version 1.0
//==

/*:
 * @plugindesc Slightly alter various formulas and make stats more interesting!
 * @author Vlue
 *
 * @param Speed Formula
 * @desc This formula determines the speed of an actor (is added on to the skill/items speed)
 * @default agi + Math.randomInt(Math.floor(5 + agi / 4))
 *
 * @param State Chance
 * @desc This formula determines the increased chance to apply a state
 * @default Math.max(1.0 + (this.subject().luk - target.luk) * 0.001, 0.0)
 *
 * @param Hit Formula
 * @desc Determines hit chance of skill (multiplied by the success rate of skill)
 * @default this.subject().hit
 *
 * @param Evasion Formula
 * @desc Determines the evasion chance of target
 * @default target.eva
 *
 * @param Magic Evasion Formula
 * @desc Determines the magic evasion chance of target
 * @default target.mev
 *
 * @param Critical Hit Formula
 * @desc Determines the chance to critically hit the target
 * @default this.subject().cri * (1 - target.cev)
 *
 * @param Counter Attack Formula
 * @desc Determines the chance to counter the attacker
 * @default target.cnt
 *
 * @param Magic Reflection Formula
 * @desc Determines the chance to reflect magic attacks
 * @default target.mrf
 *
 * @param Preemptive Chance
 * @desc Percentage chance for a preemptive strike
 * @default 5
 *
 * @param Surprise Chance
 * @desc Percentage chance to be subject to a surprise attack
 * @default 3
 *
 * @param Escape Formula
 * @desc The formula for chance to escape
 * @default 0.5 * $gameParty.agility() / $gameTroop.agility()
 *
 * @param Attack Stats
 * @desc Determine the additional bonuses of the attack stat (See help)
 * @default cnt:0.0005
 *
 * @param Defense Stats
 * @desc Determine the additional bonuses of the attack stat (See help)
 * @default hp:5, trg:0.001
 *
 * @param Magic Attack Stats
 * @desc Determine the additional bonuses of the attack stat (See help)
 * @default mp:1, mev:0.0005
 *
 * @param Magic Defense Stats
 * @desc Determine the additional bonuses of the attack stat (See help)
 * @default mrg:0.0001
 *
 * @param Agility Stats
 * @desc Determine the additional bonuses of the attack stat (See help)
 * @default eva:0.0005, hit:0.0005
 *
 * @param Luck Stats
 * @desc Determine the additional bonuses of the attack stat (See help)
 * @default cri:0.0005, cev:0.0005
 *
 * @help Interesting Stats MV
 *  Something something uh... Something.
 *
 *  Anyways, about the bonuses from stats:
 *
 * Each point in a stat adds that many points to the secondary stat.
 * Values for hp and mp are whole numbers, while everything else is
 *  float values (i.e. hit:0.001 for 0.1% chance to hit per point)
 * Options are hp,  mp,  hit, eva, cri, cev, mev, mrf, cnt
 *      hrg, mrg, trg, tgr, grd, rec, pha, mcr, tcr, pdr
 *      mdr, fdr, exr
 * 
 *
 */
 
(function() {

	var parameters = PluginManager.parameters('InterestingStats');
	var speedFormula = parameters['Speed Formula'] || "agi + Math.randomInt(Math.floor(5 + agi / 4))";
	var stateChance = parameters['State Chance'] || "Math.max(1.0 + (this.subject().luk - target.luk) * 0.001, 0.0)";
	var hitFormula = parameters['Hit Formula'] || "this.subject().hit";
	var evaFormula = parameters['Evasion Formula'] || "target.eva";
	var mevFormula = parameters['Magic Evasion Formula'] || "target.mev";
	var criFormula = parameters['Critical Hit Formula'] || "this.subject().cri * (1 - target.cev)";
	var cntFormula = parameters['Counter Attack Formula'] || "target.cnt";
	var mrfFormula = parameters['Magic Reflection Formula'] || "target.mrf";
	var preemptiveChance = parameters['Preemptive Chance'] || 5;
	var surpriseChance = parameters['Surprise Chance'] || 3;
	var escapeFormula = parameters['Escape Formula'] || "0.5 * $gameParty.agility() / $gameTroop.agility()";
	var atkHash = eval("( {" + (parameters['Attack Stats'] || "cnt:0.0005") + "} )");
	var defHash = eval("( {" + (parameters['Defense Stats'] || "hp:5, trg:0.001") + "} )");
	var matHash = eval("( {" + (parameters['Magic Attack Stats'] || "mp:1, mev:0.0005") + "} )");
	var mdfHash = eval("( {" + (parameters['Magic Defense Stats'] || "mrg:0.0001") + "} )");
	var agiHash = eval("( {" + (parameters['Agility Stats'] || "eva:0.0005, hit:0.0005") + "} )");
	var lukHash = eval("( {" + (parameters['Luck Stats'] || "cri:0.0005, cev:0.0005") + "} )");
	var bonusStats = [atkHash,defHash,matHash,mdfHash,agiHash,lukHash];
	
	Game_Battler.prototype.paramBonus = function(paramId) {
		if(paramId > 1) {return 0;}
		var sym = paramId == 0 ? "hp" : "mp";
		return this.getBonusStat(sym);
	}
	Game_Battler.prototype.xparamBonus = function(paramId) {
		var sym = ["hit","eva","cri","cev","mev","mrf","cnt","hrg","mrg","trg"][paramId];
		return this.getBonusStat(sym);
	}
	Game_Battler.prototype.sparamBonus = function(paramId) {
		var sym = ["tgr","grd","rec","pha","mcr","tcr","pdr","mdr","fdr","exr"][paramId];
		return this.getBonusStat(sym);
	}
	Game_Battler.prototype.getBonusStat = function(sym) {
		var bonus = 0
		for(var i = 0;i < bonusStats.length;i++) {
			if(eval("bonusStats[i]." + sym)) {
				bonus += eval("bonusStats[i]." + sym) * this.param(i+2);
			}
		}
		return bonus;
	}
	
	
	Game_Action.prototype.lukEffectRate = function(target) {
		return eval(stateChance);
	}
	Game_Action.prototype.itemHit = function(target) {
		var rate = this.item().success_rate * 0.01;
		if(this.isPhysical()) { rate *= eval(hitFormula);}
		return rate;
	}
	Game_Action.prototype.itemEva = function(target) {
		if (this.isPhysical()) { return eval(evaFormula); }
		else if (this.isMagical()) { return eval(mevFormula); }
		else { return 0; }
	};
	Game_Action.prototype.itemCri = function(target) {
		return this.item().damage.critical ? eval(criFormula) : 0;
	};
	Game_Action.prototype.itemCnt = function(target) {
		if (this.isPhysical() && target.canMove()) { return eval(cntFormula); }
		else { return 0; }
	};
	Game_Action.prototype.itemMrf = function(target) {
		if (this.isMagical()) {	return eval(mrfFormula); }
		else { return 0; }
	};
	Game_Action.prototype.speed = function() {
		var agi = this.subject().agi;
		var speed = eval(speedFormula);
		if (this.item()) {
			speed += this.item().speed;
		}
		if (this.isAttack()) {
			speed += this.subject().attackSpeed();
		}
		return speed;
	};
	
	Game_Party.prototype.ratePreemptive = function(troopAgi) {
		var rate = this.agility() >= troopAgi ? preemptiveChance * 0.01 : surpriseChance * 0.01;
		if (this.hasRaisePreemptive()) {
			rate *= 4;
		}
		return rate;
	};
	Game_Party.prototype.rateSurprise = function(troopAgi) {
		var rate = this.agility() >= troopAgi ? preemptiveChance * 0.01 : surpriseChance * 0.01;
		if (this.hasCancelSurprise()) {
			rate = 0;
		}
		return rate;
	};
	
	
	var stats_game_battlerbase_paramPlus = Game_BattlerBase.prototype.paramPlus;
	Game_BattlerBase.prototype.paramPlus = function(paramId) {
		return stats_game_battlerbase_paramPlus.call(this, paramId) + this.paramBonus(paramId);
	};
	
	BattleManager.makeEscapeRatio = function() {
		this._escapeRatio = eval(escapeFormula);
	};
	
})();